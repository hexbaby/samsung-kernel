/*************************************************
Author: lijunfeng
Date: 2013-06-09
Description: base structure defination for color convertor 
**************************************************/
#ifndef __COLOR_INTERFACE
#define __COLOR_INTERFACE
#ifdef WIN32
typedef __int64 int64_t ;
typedef unsigned char uint8_t;
#define NULL 0
#endif

#define PIX_FMT_YUV420P 0
#define PIX_FMT_YUYV422 1
#define PIX_FMT_RGB24 2
#define PIX_FMT_BGR24 3
#define PIX_FMT_YUVJ420P 12
#define AV_PIX_FMT_UYVY422 17
#define PIX_FMT_NV12 25
#define PIX_FMT_NV21 26
#define PIX_FMT_RGBA 28
#define PIX_FMT_RGB565LE 44
#define PIX_FMT_BGR565LE 48

enum{
	ffcodec_color_create=30,
	ffcodec_color_destroy,
	ffcodec_color_convert,
	ffcodec_color_init,
};

typedef int (*common_cmd_fn)(void* session,int cmd,int param1,int param2);

typedef struct colorspace_init_param
{
	int srcFormat;
	int srcW;
	int srcH;
	int dstFormat;
}colorspace_init_param;

typedef struct colorspace_convert_param
{
	uint8_t* data[4];
	int stride[4];
}colorspace_convert_param;
#endif
