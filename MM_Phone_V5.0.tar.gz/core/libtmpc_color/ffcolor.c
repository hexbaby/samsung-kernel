
#include "libswscale/swscale.h"
#include "libswscale/swscale_internal.h"
#include "color_intf.h"
#define LOG_NDEBUG 0
#define LOG_TAG "ffcodec"
#include <utils/Log.h>

typedef struct colorspace_convert
{
	void *Context;
	colorspace_init_param param;
	uint8_t* src[4];
	int srcStride[4];
	uint8_t* dst[4];
	int dstStride[4];
}colorspace_convert;

static void init_default_colorparams(int fmt,int width,int height,uint8_t* src[],int srcStride[])
{
	switch(fmt)
	{
		case PIX_FMT_RGB24:
		case PIX_FMT_BGR24:
			srcStride[0] = width*3;
			break;
		case PIX_FMT_YUYV422:
		case PIX_FMT_RGB565LE:
		case PIX_FMT_BGR565LE:
			srcStride[0] = width*2;
			break;
		case PIX_FMT_YUV420P:
		case PIX_FMT_YUVJ420P:
			srcStride[0] = width;			
			srcStride[1] = width/2;
			srcStride[2] = width/2;
			src[1] = src[0]+width*height;
			src[2] = src[1]+width*height/4;
			break;
		case PIX_FMT_NV12:
		case PIX_FMT_NV21:
			srcStride[0] = width;			
			srcStride[1] = width/2;
			srcStride[2] = width/2;
			src[1] = src[0]+width*height;
			src[2] = src[1];
			break;
		/* gongjia add */
        	case PIX_FMT_RGBA:
                case PIX_FMT_BGRA:
                       srcStride[0] = width*4;
                       break;
                case AV_PIX_FMT_UYVY422:
                       srcStride[0] = width*2;
                       break;
        	/* end */
	}
}
////////////////////////////////color space
static colorspace_convert* colorspace_create_converter(colorspace_init_param* param)
{
	colorspace_convert* clr;
	int flags = SWS_BICUBIC;//SWS_FAST_BILINEAR;	
	if( !param )
		return NULL;

    void* Context = sws_getContext(param->srcW, param->srcH, param->srcFormat, param->srcW, param->srcH, 
		param->dstFormat, flags, NULL, NULL, NULL);
	if( !Context )
		return NULL;
	clr = (colorspace_convert*)malloc( sizeof(colorspace_convert) );
	if( NULL == clr )
	{
		sws_freeContext( (SwsContext*)(Context) );
		return NULL;	
	}
		LOGI("ffcolor_cmd colorspace_create_converter trace(%dx%d %d %d)",param->srcW, param->srcH, param->srcFormat,param->dstFormat);
	memset(clr,0,sizeof(colorspace_convert));
	
	memcpy(&clr->param,param,sizeof(colorspace_init_param));
	clr->Context = Context;
	return clr;
}
static void colorspace_destroy_converter(colorspace_convert* clr)
{
	if( !clr ) return;
	if( clr->Context )
	{
		sws_freeContext( (SwsContext*)(clr->Context) );
		clr->Context = NULL;
	}
	free(clr);
}
static int colorspace_init(colorspace_convert* clr,colorspace_convert_param* in,colorspace_convert_param* out)
{
	if( !clr || !clr->Context )
		return -1;
	if( in )
	{
		if( (in->stride[0] == 0)&&(in->data[0] == NULL) )
			return -1;
		if( in->stride[0] == 0 )
		{
			clr->src[0] = in->data[0];
			init_default_colorparams(clr->param.srcFormat,clr->param.srcW,clr->param.srcH,clr->src,clr->srcStride);
		}else
		{
			clr->src[0] = in->data[0];
			clr->src[1] = in->data[1];
			clr->src[2] = in->data[2];
			clr->srcStride[0] = in->stride[0];
			clr->srcStride[1] = in->stride[1];
			clr->srcStride[2] = in->stride[2];
		}
	}
	if( out )
	{
		if( (out->stride[0] == 0)&&(out->data[0] == NULL) )
			return -1;
		if( out->stride[0] == 0 )
		{
			clr->dst[0] = out->data[0];
			init_default_colorparams(clr->param.dstFormat,clr->param.srcW,clr->param.srcH,clr->dst,clr->dstStride);
		}else
		{
			clr->dst[0] = out->data[0];
			clr->dst[1] = out->data[1];
			clr->dst[2] = out->data[2];
			clr->dstStride[0] = out->stride[0];
			clr->dstStride[1] = out->stride[1];
			clr->dstStride[2] = out->stride[2];
		}
	}   	
	return 0;
}
#if 0
void yuv420_2_rgb565(uint16_t *dst_ptr,
               const uint8_t  *y_ptr,
               const uint8_t  *u_ptr,
               const uint8_t  *v_ptr,
                     int32_t   width,
                     int32_t   height,
                     int32_t   y_span,
                     int32_t   uv_span,
                     int32_t   dst_span);
void yuv420_to_rgb_fast(
	const unsigned char * yuv420[3], // yuv420
	int width, // assume W%2 == 0
	int height, // assume H%2 == 0
	const int stride_s[3], // stride of lum, assume strides of U,V are stride_s/2
	void* rgb_out, // rgb, must be 4 byte-aligned for rgb32 or 2 byte-aligned for rgb16
	int rgb_size_in_byte, // 4 or 2
	int stride_d,  // rgb stride, in int32_t or int16_t unit, if it's 0, then calculate it
	int rotate_flag  // 0 = no rotation; 1 = clock-wise, +pi/2; 
	);
#endif

static int colorspace_do_convert(colorspace_convert* clr,colorspace_convert_param* in,colorspace_convert_param* out)
{
	if( !clr || !clr->Context )
		return -1;
	colorspace_init(clr,in,out);
   	sws_scale((SwsContext*)clr->Context, clr->src, clr->srcStride, 0, clr->param.srcH, clr->dst, clr->dstStride);	
	#if 0
			yuv420_2_rgb565((uint16_t *)clr->dst[0],
				 clr->src[0],
				 clr->src[1],
				 clr->src[2],
				 clr->param.srcW,
				 clr->param.srcH,
				 clr->srcStride[0],
				 clr->srcStride[1],
				 clr->dstStride[0]);
		yuv420_to_rgb_fast(clr->src,clr->param.srcW,clr->param.srcH, clr->srcStride,
			clr->dst[0], 2, clr->param.srcW, 0);
	#endif
	return 0;
}
////////////////////////////////externel interface
int ffcolor_cmd(void*this,int cmd,int param1,int param2)
{
	int ret = 0;
//	LOGI("ffcolor_cmd %d %x %x",cmd,param1,param2);
	switch(cmd)
	{
		case ffcodec_color_create:
			ret = (int)colorspace_create_converter( (colorspace_init_param*)param1 );
			break;			
		case ffcodec_color_destroy:
			colorspace_destroy_converter( (colorspace_convert*)this );
			break;
		case ffcodec_color_convert:
			ret = colorspace_do_convert( (colorspace_convert*)this,(colorspace_convert_param*)param1,(colorspace_convert_param*)param2 );
			break;
		case ffcodec_color_init:
			ret = colorspace_init( (colorspace_convert*)this,(colorspace_convert_param*)param1,(colorspace_convert_param*)param2 );
			break;
		default:
			break;
	}
//	LOGI("ffcolor_cmd %d %x %x out",cmd,param1,param2);
	return ret;
}
