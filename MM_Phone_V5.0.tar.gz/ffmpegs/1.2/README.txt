trunk��ffmpeg is source code
build is compile script

